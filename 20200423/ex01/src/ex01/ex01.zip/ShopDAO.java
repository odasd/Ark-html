package ex01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ShopDAO {
	
	public Connection con() throws Exception {
        String driver = "oracle.jdbc.driver.OracleDriver";
        String url = "jdbc:oracle:thin:@localhost:1521:orcl";
        String user = "system";
        String password = "159752s";

        Class.forName(driver);
        Connection con = DriverManager.getConnection(url, user, password);
        return con;
        }
	
	public void insert(ShopVO vo) throws Exception {
		String sql="insert into tbl_shop(sid, title, lprice, hprice, wdate,img) values(?,?,?,?,sysdate,?)";
		PreparedStatement ps=con().prepareStatement(sql);
		
		ps.setString(1, vo.getSid());
		ps.setString(2, vo.getTitle());
		ps.setInt(3, vo.getLprice());
		ps.setInt(4, vo.getHprice());
		ps.setString(5, vo.getImg());
		ps.execute();
		con().close();
	}
	
	//��ü �����Ͱ��� ���
	
	public int count() throws Exception{
		int count=0;
		String sql="select count(*) cnt from tbl_shop";
		PreparedStatement ps=con().prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		
		if(rs.next()) {
			count=rs.getInt("cnt");
		}
		con().close();
		
		return count;
	}
	
}
